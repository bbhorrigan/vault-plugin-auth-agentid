# vault-plugin-auth-mcp
